import json
import logging
import requests

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """MCP Proxy supporting all three servers (security, cost, roi)"""
    
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract API path and method from Bedrock Agent event
        api_path = event.get('apiPath', '')
        http_method = event.get('httpMethod', 'POST')
        
        # Extract request body
        request_body = {}
        if 'requestBody' in event:
            content = event['requestBody'].get('content', {})
            if 'application/json' in content:
                request_body = json.loads(content['application/json'])
        
        logger.info(f"API Path: {api_path}, Method: {http_method}")
        logger.info(f"Request Body: {json.dumps(request_body, indent=2)}")
        
        # Route to appropriate MCP server
        gateway_url = 'https://yko4kspo9e.execute-api.us-east-1.amazonaws.com/prod'
        
        # Determine MCP server and tool from API path
        mcp_endpoint = None
        tool_name = None
        action_group = event.get('actionGroup', 'analytics-tools')
        
        if api_path.startswith('/security/'):
            tool_name = api_path.replace('/security/', '')
            mcp_endpoint = f"{gateway_url}/security"
        elif api_path.startswith('/cost/'):
            tool_name = api_path.replace('/cost/', '')
            mcp_endpoint = f"{gateway_url}/cost"
        elif api_path.startswith('/roi/'):
            tool_name = api_path.replace('/roi/', '')
            mcp_endpoint = f"{gateway_url}/roi"
        else:
            logger.error(f"Unknown API path: {api_path}")
            return {
                'messageVersion': '1.0',
                'response': {
                    'actionGroup': action_group,
                    'apiPath': api_path,
                    'httpMethod': http_method,
                    'httpStatusCode': 404,
                    'responseBody': {
                        'application/json': {
                            'body': json.dumps({
                                "error": f"Unknown API path: {api_path}"
                            })
                        }
                    }
                }
            }
        
        # Prepare MCP request
        mcp_request = {
            "tool": tool_name,
            "arguments": request_body
        }
        
        logger.info(f"Calling MCP endpoint: {mcp_endpoint}")
        logger.info(f"MCP request: {json.dumps(mcp_request, indent=2)}")
        
        # Call MCP server
        response = requests.post(
            mcp_endpoint,
            json=mcp_request,
            timeout=25,
            headers={'Content-Type': 'application/json'}
        )
        
        logger.info(f"MCP response status: {response.status_code}")
        logger.debug(f"MCP response: {response.text}")
        
        if response.status_code == 200:
            mcp_result = response.json()
            
            # Format response for Bedrock Agent
            formatted_response = {
                "tool_name": tool_name,
                "result": mcp_result,
                "status": "success"
            }
            
            return {
                'messageVersion': '1.0',
                'response': {
                    'actionGroup': action_group,
                    'apiPath': api_path,
                    'httpMethod': http_method,
                    'httpStatusCode': 200,
                    'responseBody': {
                        'application/json': {
                            'body': json.dumps(formatted_response)
                        }
                    }
                }
            }
        else:
            logger.error(f"MCP server error: {response.status_code} - {response.text}")
            return {
                'messageVersion': '1.0',
                'response': {
                    'actionGroup': action_group,
                    'apiPath': api_path,
                    'httpMethod': http_method,
                    'httpStatusCode': 500,
                    'responseBody': {
                        'application/json': {
                            'body': json.dumps({
                                "error": f"MCP server error: {response.status_code}",
                                "details": response.text
                            })
                        }
                    }
                }
            }
            
    except Exception as e:
        logger.error(f"MCP Proxy error: {str(e)}")
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': event.get('actionGroup', 'analytics-tools'),
                'apiPath': event.get('apiPath', '/unknown'),
                'httpMethod': event.get('httpMethod', 'POST'),
                'httpStatusCode': 500,
                'responseBody': {
                    'application/json': {
                        'body': json.dumps({
                            "error": f"MCP Proxy error: {str(e)}"
                        })
                    }
                }
            }
        }
